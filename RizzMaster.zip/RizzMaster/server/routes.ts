import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { nanoid } from "nanoid";
import { generateBotResponse } from "../client/src/lib/rizzResponses";
import { RizzStyle } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get messages for a conversation
  app.get("/api/messages/:conversationId", async (req, res) => {
    try {
      const { conversationId } = req.params;
      const messages = await storage.getMessagesByConversationId(conversationId);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  // Send a message and get a response
  app.post("/api/messages", async (req, res) => {
    try {
      const { content, conversationId, style } = req.body;
      
      if (!content || !conversationId) {
        return res.status(400).json({ message: "Content and conversationId are required" });
      }

      // Save user message
      const userMessage = await storage.saveMessage({
        content,
        isUser: true,
        conversationId,
      });

      // Generate bot response based on user message and selected style
      const botResponseContent = generateBotResponse(content, style as RizzStyle || "smooth");
      
      // Save bot response
      const botResponse = await storage.saveMessage({
        content: botResponseContent,
        isUser: false,
        conversationId,
      });

      res.status(201).json({ 
        userMessage,
        botResponse 
      });
    } catch (error) {
      console.error("Error processing message:", error);
      res.status(500).json({ message: "Failed to process message" });
    }
  });

  // Create HTTP server
  const httpServer = createServer(app);

  return httpServer;
}
