import { RizzStyle } from "@shared/schema";

interface RizzStyleSelectorProps {
  selectedStyle: RizzStyle;
  onSelectStyle: (style: RizzStyle) => void;
}

interface StyleOption {
  value: RizzStyle;
  label: string;
  icon: JSX.Element;
}

export default function RizzStyleSelector({ 
  selectedStyle, 
  onSelectStyle 
}: RizzStyleSelectorProps) {
  
  const styleOptions: StyleOption[] = [
    {
      value: "smooth",
      label: "Smooth",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M9.59 4.59A2 2 0 1 1 11 8H2m10.59 11.41A2 2 0 1 0 14 16H2"></path>
        </svg>
      )
    },
    {
      value: "cheesy",
      label: "Cheesy",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M10.5 20H4a2 2 0 0 1-2-2V5c0-1.1.9-2 2-2h3.93a2 2 0 0 1 1.66.9l.82 1.2a2 2 0 0 0 1.66.9H20a2 2 0 0 1 2 2v3"></path>
          <circle cx="18" cy="18" r="3"></circle>
          <path d="m16.9 15.33-3.95-2.64"></path>
        </svg>
      )
    },
    {
      value: "poetic",
      label: "Poetic",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M20.24 12.24a6 6 0 0 0-8.49-8.49L5 10.5V19h8.5l6.74-6.76z"></path>
          <line x1="16" y1="8" x2="2" y2="22"></line>
          <line x1="17.5" y1="15" x2="9" y2="15"></line>
        </svg>
      )
    },
    {
      value: "funny",
      label: "Funny",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="12" r="10"></circle>
          <path d="M8 14s1.5 2 4 2 4-2 4-2"></path>
          <line x1="9" y1="9" x2="9.01" y2="9"></line>
          <line x1="15" y1="9" x2="15.01" y2="9"></line>
        </svg>
      )
    },
    {
      value: "confident",
      label: "Confident",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M2 4h20v7H2z"></path>
          <path d="M6 11v9"></path>
          <path d="M18 11v9"></path>
          <path d="M12 11v9"></path>
          <path d="M4 4v7"></path>
          <path d="M20 4v7"></path>
        </svg>
      )
    }
  ];
  
  return (
    <div className="bg-white px-4 py-2 flex overflow-x-auto gap-2 shadow-sm">
      {styleOptions.map((option) => (
        <button
          key={option.value}
          onClick={() => onSelectStyle(option.value)}
          className={`px-4 py-1.5 rounded-full text-sm font-medium ${
            selectedStyle === option.value
              ? "bg-secondary text-white shadow-sm"
              : "bg-gray-100 text-gray-700 hover:bg-gray-200 transition-colors"
          } flex items-center`}
        >
          <span className="mr-2">{option.icon}</span>
          {option.label}
        </button>
      ))}
    </div>
  );
}
