import { useEffect, useRef } from "react";
import { ChatMessage } from "@/pages/Home";
import Message from "./Message";
import TypingIndicator from "./TypingIndicator";

interface MessageContainerProps {
  messages: ChatMessage[];
  isTyping: boolean;
}

export default function MessageContainer({
  messages,
  isTyping
}: MessageContainerProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom when messages change
  useEffect(() => {
    if (containerRef.current) {
      containerRef.current.scrollTop = containerRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  return (
    <div 
      ref={containerRef}
      className="flex-1 overflow-y-auto p-4 bg-transparent"
    >
      {messages.map((message) => (
        <Message 
          key={message.id} 
          message={message} 
        />
      ))}
      
      {isTyping && <TypingIndicator />}
      
      {/* Add extra space at the bottom to ensure scrolling works properly */}
      <div className="h-4"></div>
    </div>
  );
}
