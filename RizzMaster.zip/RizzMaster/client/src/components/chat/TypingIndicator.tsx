export default function TypingIndicator() {
  return (
    <div className="flex items-end mb-4">
      <div className="bg-gray-200 rounded-full p-3 flex items-end shadow-sm">
        <span className="w-2 h-2 bg-gray-400 rounded-full block mr-1 animate-[typing_1s_infinite]" style={{ animationDelay: "0s" }}></span>
        <span className="w-2 h-2 bg-gray-400 rounded-full block mr-1 animate-[typing_1s_infinite]" style={{ animationDelay: "0.2s" }}></span>
        <span className="w-2 h-2 bg-gray-400 rounded-full block animate-[typing_1s_infinite]" style={{ animationDelay: "0.4s" }}></span>
      </div>
    </div>
  );
}
