import { ChatMessage } from "@/pages/Home";

interface MessageProps {
  message: ChatMessage;
}

export default function Message({ message }: MessageProps) {
  // Format the timestamp for display
  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    let hours = date.getHours();
    const minutes = date.getMinutes().toString().padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; // Convert 0 to 12
    return `${hours}:${minutes} ${ampm}`;
  };

  return (
    <div className={`flex items-end ${message.isUser ? 'justify-end' : ''} mb-4`}>
      <div className={`flex-1 ${message.isUser ? 'ml-4 max-w-[80%] flex flex-col items-end' : 'mr-4 max-w-[80%]'}`}>
        <div 
          className={`${
            message.isUser 
              ? 'bg-primary text-white rounded-t-xl rounded-bl-xl' 
              : 'bg-white rounded-t-xl rounded-br-xl'
          } p-3 shadow-sm`}
        >
          <p className="whitespace-pre-wrap">{message.content}</p>
        </div>
        <span className={`text-xs text-gray-500 ${message.isUser ? 'mr-1' : 'ml-1'} mt-1 inline-block`}>
          {formatTime(message.timestamp)}
        </span>
      </div>
    </div>
  );
}
