import { useState, useEffect } from "react";
import { nanoid } from "nanoid";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { RizzStyle } from "@shared/schema";
import ChatHeader from "@/components/chat/ChatHeader";
import RizzStyleSelector from "@/components/chat/RizzStyleSelector";
import MessageContainer from "@/components/chat/MessageContainer";
import MessageInput from "@/components/chat/MessageInput";

export type ChatMessage = {
  id: string;
  content: string;
  isUser: boolean;
  timestamp: string;
};

export default function Home() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [selectedStyle, setSelectedStyle] = useState<RizzStyle>("smooth");
  const [isTyping, setIsTyping] = useState(false);
  const [conversationId, setConversationId] = useState<string>("");

  // Initialize conversation
  useEffect(() => {
    const id = localStorage.getItem("conversationId") || nanoid();
    setConversationId(id);
    localStorage.setItem("conversationId", id);
  }, []);

  // Fetch conversation history
  const { data: conversationData, isLoading } = useQuery({
    queryKey: [`/api/messages/${conversationId}`],
    enabled: !!conversationId,
  });

  // Set conversation history from query data
  useEffect(() => {
    if (conversationData) {
      setMessages(conversationData);
    } else if (!isLoading && conversationId && !messages.length) {
      // Add welcome message if no conversation history
      addBotMessage(
        "Hey there! I'm RizzBot, your personal flirt assistant. I'll keep the conversation spicy with my smooth lines 😎 How are you feeling today?"
      );
    }
  }, [conversationData, conversationId, isLoading]);

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (message: string) => {
      const response = await apiRequest("POST", "/api/messages", {
        content: message,
        isUser: true,
        conversationId,
        style: selectedStyle,
      });
      return response.json();
    },
    onSuccess: (data) => {
      // Add user message
      setMessages((prev) => [...prev, {
        id: nanoid(),
        content: data.userMessage.content,
        isUser: true,
        timestamp: new Date().toISOString(),
      }]);
      
      // Show typing indicator
      setIsTyping(true);
      
      // After delay, add bot response
      setTimeout(() => {
        setIsTyping(false);
        addBotMessage(data.botResponse.content);
      }, 1500);
      
      // Invalidate queries to refresh conversation
      queryClient.invalidateQueries({ queryKey: [`/api/messages/${conversationId}`] });
    },
  });

  // Helper to add bot message
  const addBotMessage = (content: string) => {
    setMessages((prev) => [...prev, {
      id: nanoid(),
      content,
      isUser: false,
      timestamp: new Date().toISOString(),
    }]);
  };

  // Handle send message
  const handleSendMessage = (message: string) => {
    if (!message.trim()) return;
    sendMessageMutation.mutate(message);
  };

  return (
    <div className="h-screen flex flex-col bg-gradient-to-br from-gray-50 to-gray-200 overflow-hidden font-sans">
      <ChatHeader />
      <RizzStyleSelector 
        selectedStyle={selectedStyle}
        onSelectStyle={setSelectedStyle}
      />
      <MessageContainer 
        messages={messages}
        isTyping={isTyping}
      />
      <MessageInput onSendMessage={handleSendMessage} />
    </div>
  );
}
