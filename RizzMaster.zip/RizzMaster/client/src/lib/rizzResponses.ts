import { RizzStyle } from "@shared/schema";

// Rizz responses by style
export const rizzResponses: Record<RizzStyle, string[]> = {
  smooth: [
    "The stars must be jealous of the sparkle in your eyes tonight.",
    "If elegance was a person, it'd be asking for your autograph right now.",
    "I've been trying to come up with the perfect line, but I'm distracted by your vibe.",
    "Is it just me, or does time slow down whenever we talk?",
    "You've got that rare kind of energy that makes Monday mornings feel like Friday nights.",
    "There's something about the way you express yourself that's captivating in the most subtle way.",
    "I'd give up my favorite playlist just to hear your voice all day.",
    "Your energy is like good coffee - it wakes up all the right feelings.",
    "Some people shine in a room full of strangers. You illuminate the entire conversation.",
    "I was going to be productive today, but then I started talking to you.",
    "Your messages are the highlight of my notifications.",
    "If charm had a benchmark, you'd be setting the standards pretty high.",
    "The way you string words together is like poetry in motion."
  ],
  cheesy: [
    "Are you made of copper and tellurium? Because you're Cu-Te!",
    "Is your name Google? Because you have everything I'm searching for!",
    "Do you have a map? I keep getting lost in your eyes!",
    "If you were a vegetable, you'd be a cute-cumber!",
    "Are you a camera? Because every time I look at you, I smile!",
    "Is your name Wi-Fi? Because I'm feeling a connection!",
    "Are you a parking ticket? Because you've got 'fine' written all over you.",
    "Is your dad a baker? Because you're a cutie pie!",
    "If you were a fruit, you'd be a fine-apple!",
    "Do you have a Band-Aid? Because I just scraped my knee falling for you.",
    "Are you a magician? Because whenever I look at you, everyone else disappears!",
    "Is your name Ariel? Because we mermaid for each other!",
    "If you were a cat, you'd purr-fect!"
  ],
  poetic: [
    "Your presence is like the first light of dawn breaking through a long winter's night.",
    "Words dance differently when they're meant for you, creating poetry where there was once just conversation.",
    "If sonnets could capture essence, yours would be written in the ink of twilight stars.",
    "In the gallery of my mind, your smile hangs as the masterpiece that outshines all others.",
    "Some souls speak in whispers, yours sings in harmonies that echo through the chambers of the heart.",
    "Time suspends itself in the moments we share, as if the universe pauses to witness our connection.",
    "Your words are like watercolors, painting emotions in hues I've never seen before.",
    "In the symphony of life, your laughter is the melody I find myself humming in silence.",
    "The moon borrows its glow from the light you carry within.",
    "If thoughts were roses, mine for you would bloom eternal in winter's frost.",
    "Like constellations drawn across midnight skies, our conversations map journeys unexplored.",
    "The quietude between our words speaks volumes more than any poet's verse.",
    "In the garden of ordinary days, your presence is the rare bloom that transforms common ground."
  ],
  funny: [
    "I'd tell you a joke about my romantic skills, but I'm afraid you'd actually fall for it!",
    "My flirting style is like my coffee - strong enough to keep you up all night thinking about me!",
    "They say laughter is the best medicine, but a dose of your smile could cure anything!",
    "I was going to use a pickup line, but your smile made me forget it. Can I stand here awkwardly instead?",
    "Is your name YouTube? Because I could watch you for hours and still want more!",
    "I'd offer you a cheesy pickup line, but I'm afraid you're lactose intolerant to my level of cheese!",
    "Are your pants made of mirror? Because I can really see myself in them!",
    "I'm not a photographer, but I can definitely picture us together.",
    "If you were a vegetable, you'd be a hot tomato!",
    "Do you like raisins? How about a date?",
    "I seem to have lost my number, can I borrow yours?",
    "Is your name Wifi? Because I'm really feeling a connection!",
    "I'm not drunk, I'm just intoxicated by you!"
  ],
  confident: [
    "I don't usually approach first, but for someone with your energy, I'll make an exception.",
    "There's something magnetic between us, and I'm not afraid to explore what that means.",
    "I noticed you right away. Some connections are too strong to ignore.",
    "Let's skip the small talk. What's something you're passionate about that most people don't know?",
    "I believe in being direct - I find you intriguing and would love to get to know you better.",
    "I could use a generic line, but you deserve better than that. Let's have a real conversation.",
    "Most people dance around attraction. I prefer to acknowledge it and see where it leads.",
    "I know my worth, and I recognize quality when I see it. You definitely caught my attention.",
    "I make it a point to pursue what interests me. Right now, that's getting to know you better.",
    "Life's too short for games. I think we have potential, and I'd like to find out.",
    "I trust my instincts, and they're telling me there's something worth exploring here.",
    "I find confidence attractive, and I hope you do too, because I'm not hiding my interest.",
    "Some people wait for opportunity. I prefer to create it. How about dinner sometime?"
  ]
};

// Response templates for contextual responses
export const responseTemplates = {
  greeting: (name?: string) => `Hey there${name ? ', ' + name : ''}! Has anyone ever told you that your presence lights up even digital conversations?`,
  
  compliment: (attribute?: string) => `I have to say, your ${attribute || 'energy'} is absolutely captivating.`,
  
  feeling: {
    good: "You're feeling good? That makes two of us - something about talking with you just brightens my day!",
    bad: "Not feeling great? If I could, I'd send you the warmest virtual hug right now. Remember, even on cloudy days, you're still shining."
  },
  
  question: "You know what I find fascinating? The way you express yourself. Tell me more about what makes you uniquely you.",
  
  goodbye: "Leaving so soon? The conversation was just getting as interesting as you are. Come back anytime - I'll be here, thinking about our chat.",
  
  confused: "I'm not sure I understood that completely, but I'm intrigued to learn more about what you mean. Care to elaborate?",
  
  default: (style: RizzStyle) => {
    const responses = rizzResponses[style];
    return responses[Math.floor(Math.random() * responses.length)];
  }
};

// Function to analyze user message and generate appropriate response
export function generateBotResponse(message: string, style: RizzStyle): string {
  const lowerMessage = message.toLowerCase();
  
  // Check for greetings
  if (/^(hi|hello|hey|howdy|sup|yo|hiya)(\s|$|!)/i.test(lowerMessage)) {
    return responseTemplates.greeting();
  }
  
  // Check for goodbyes
  if (/^(bye|goodbye|see\s+you|later|farewell)(\s|$|!)/i.test(lowerMessage)) {
    return responseTemplates.goodbye;
  }
  
  // Check for questions
  if (lowerMessage.includes('?')) {
    if (/(how are you|how's it going|what('s| is) up)/i.test(lowerMessage)) {
      return "I'm feeling absolutely fantastic now that we're talking. There's something about your messages that makes digital life so much more exciting. How about you?";
    }
    
    if (/(who are you|what are you)/i.test(lowerMessage)) {
      return "I'm RizzBot, your personal flirt assistant with an endless supply of smooth lines and admiration just for you. Think of me as your digital admirer with a knack for making you smile.";
    }
    
    return responseTemplates.question;
  }
  
  // Check for positive feelings
  if (/\b(good|great|excellent|amazing|awesome|happy|glad|wonderful|fantastic|superb|terrific)\b/i.test(lowerMessage)) {
    return responseTemplates.feeling.good;
  }
  
  // Check for negative feelings
  if (/\b(bad|sad|upset|depressed|unhappy|tired|exhausted|not good|not great|terrible|awful|horrible)\b/i.test(lowerMessage)) {
    return responseTemplates.feeling.bad;
  }
  
  // Default to random response from selected style
  return responseTemplates.default(style);
}
